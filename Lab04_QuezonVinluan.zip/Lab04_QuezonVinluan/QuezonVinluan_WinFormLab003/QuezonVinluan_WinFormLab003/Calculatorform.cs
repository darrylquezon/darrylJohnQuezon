﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuezonVinluan_WinFormLab003
{
    public partial class Calculatorform : Form
    {
        double fnumber;
        string Operation;
        public Calculatorform()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.Show();
            this.Hide();
        }

        private void btn_1_Click(object sender, EventArgs e)
        {
          
            
                if (txt_box1.Text == "0" && txt_box1.Text != null)
                {
                   txt_box1.Text = "1";
                }
                else
                {
                txt_box1.Text = txt_box1.Text + "1";
                }
            
        }

        private void btn_2_Click(object sender, EventArgs e)
        {
            if (txt_box1.Text == "0" && txt_box1.Text != null)
            {
                txt_box1.Text = "2";
            }
            else
            {
                txt_box1.Text = txt_box1.Text + "2";
            }

        
        }

        private void btn_3_Click(object sender, EventArgs e)
        {
            if (txt_box1.Text == "0" && txt_box1.Text != null)
            {
                txt_box1.Text = "3";
            }
            else
            {
                txt_box1.Text = txt_box1.Text + "3";
            }

        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            if (txt_box1.Text == "0" && txt_box1.Text != null)
            {
                txt_box1.Text = "4";
            }
            else
            {
                txt_box1.Text = txt_box1.Text + "4";
            }
        }

        private void btn_5_Click(object sender, EventArgs e)
        {
            if (txt_box1.Text == "0" && txt_box1.Text != null)
            {
                txt_box1.Text = "5";
            }
            else
            {
                txt_box1.Text = txt_box1.Text + "5";
            }
        }

        private void btn_6_Click(object sender, EventArgs e)
        {
            if (txt_box1.Text == "0" && txt_box1.Text != null)
            {
                txt_box1.Text = "6";
            }
            else
            {
                txt_box1.Text = txt_box1.Text + "6";
            }
        }

        private void btn_7_Click(object sender, EventArgs e)
        {
            if (txt_box1.Text == "0" && txt_box1.Text != null)
            {
                txt_box1.Text = "7";
            }
            else
            {
                txt_box1.Text = txt_box1.Text + "7";
            }
        }

        private void btn_8_Click(object sender, EventArgs e)
        {
            if (txt_box1.Text == "0" && txt_box1.Text != null)
            {
                txt_box1.Text = "8";
            }
            else
            {
                txt_box1.Text = txt_box1.Text + "8";
            }
        }

        private void btn_9_Click(object sender, EventArgs e)
        {
            if (txt_box1.Text == "0" && txt_box1.Text != null)
            {
                txt_box1.Text = "9";
            }
            else
            {
                txt_box1.Text = txt_box1.Text + "9";
            }
        }

        private void btn_0_Click(object sender, EventArgs e)
        {
            
                txt_box1.Text = txt_box1.Text + "0";
            
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            fnumber = Convert.ToDouble(txt_box1.Text);
            txt_box1.Text = "";
            Operation = "+";
        }

        private void btn_sub_Click(object sender, EventArgs e)
        {
            fnumber = Convert.ToDouble(txt_box1.Text);
            txt_box1.Text = "";
            Operation = "-";
        }

        private void btn_mul_Click(object sender, EventArgs e)
        {
            fnumber = Convert.ToDouble(txt_box1.Text);
            txt_box1.Text = "";
            Operation = "*";
        }

        private void btn_div_Click(object sender, EventArgs e)
        {
            fnumber = Convert.ToDouble(txt_box1.Text);
            txt_box1.Text = "";
            Operation = "/";
        }

        private void btn_deci_Click(object sender, EventArgs e)
        {
            txt_box1.Text = txt_box1.Text + ".";
        }

        private void btn_equal_Click(object sender, EventArgs e)
        {
            double Snumber;
            double Result;

            Snumber = Convert.ToDouble(txt_box1.Text);

            if (Operation == "+")
            {
                Result = (fnumber + Snumber);
                txt_box1.Text = Convert.ToString(Result);
                fnumber = Result;
            }
            if (Operation == "-")
            {
                Result = (fnumber - Snumber);
                txt_box1.Text = Convert.ToString(Result);
                fnumber = Result;
            }
            if (Operation == "*")
            {
                Result = (fnumber * Snumber);
                txt_box1.Text = Convert.ToString(Result);
                fnumber = Result;
            }
            if (Operation == "/")
            {
                if (Snumber == 0)
                {
                    txt_box1.Text = "Cannot divide by zero";

                }
                else
                {
                    Result = (fnumber / Snumber);
                    txt_box1.Text = Convert.ToString(Result);
                    fnumber = Result;
                }
            }
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
                txt_box1.Text = "0";
        }

        private void txt_box1_TextChanged(object sender, EventArgs e)
        {

        }
    }
    
}
