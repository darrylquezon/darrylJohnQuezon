﻿namespace QuezonVinluan_WinFormLab003
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.label1 = new System.Windows.Forms.Label();
            this.btn_integer = new System.Windows.Forms.Button();
            this.btn_double = new System.Windows.Forms.Button();
            this.btn_float = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_comSum = new System.Windows.Forms.Button();
            this.btn_Nextfrm = new System.Windows.Forms.Button();
            this.btn_closefrm = new System.Windows.Forms.Button();
            this.txtsnum = new System.Windows.Forms.TextBox();
            this.txtfnum = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F);
            this.label1.Location = new System.Drawing.Point(52, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(370, 44);
            this.label1.TabIndex = 0;
            this.label1.Text = "Computer Calculator";
            // 
            // btn_integer
            // 
            this.btn_integer.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btn_integer.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btn_integer.Location = new System.Drawing.Point(20, 82);
            this.btn_integer.Name = "btn_integer";
            this.btn_integer.Size = new System.Drawing.Size(178, 34);
            this.btn_integer.TabIndex = 1;
            this.btn_integer.Text = "Integer";
            this.btn_integer.UseVisualStyleBackColor = false;
            this.btn_integer.Click += new System.EventHandler(this.btn_integer_Click);
            // 
            // btn_double
            // 
            this.btn_double.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btn_double.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btn_double.Location = new System.Drawing.Point(204, 82);
            this.btn_double.Name = "btn_double";
            this.btn_double.Size = new System.Drawing.Size(206, 34);
            this.btn_double.TabIndex = 2;
            this.btn_double.Text = "Double";
            this.btn_double.UseVisualStyleBackColor = false;
            this.btn_double.Click += new System.EventHandler(this.btn_double_Click);
            // 
            // btn_float
            // 
            this.btn_float.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btn_float.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btn_float.Location = new System.Drawing.Point(416, 82);
            this.btn_float.Name = "btn_float";
            this.btn_float.Size = new System.Drawing.Size(171, 34);
            this.btn_float.TabIndex = 3;
            this.btn_float.Text = "Float";
            this.btn_float.UseVisualStyleBackColor = false;
            this.btn_float.Click += new System.EventHandler(this.btn_float_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label2.Location = new System.Drawing.Point(16, 147);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "Enter First Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label3.Location = new System.Drawing.Point(300, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(159, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "Enter Second Number:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // btn_comSum
            // 
            this.btn_comSum.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btn_comSum.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btn_comSum.Location = new System.Drawing.Point(204, 197);
            this.btn_comSum.Name = "btn_comSum";
            this.btn_comSum.Size = new System.Drawing.Size(206, 39);
            this.btn_comSum.TabIndex = 8;
            this.btn_comSum.Text = "Compute Sum";
            this.btn_comSum.UseVisualStyleBackColor = false;
            this.btn_comSum.Click += new System.EventHandler(this.btn_comSum_Click);
            // 
            // btn_Nextfrm
            // 
            this.btn_Nextfrm.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btn_Nextfrm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btn_Nextfrm.Location = new System.Drawing.Point(204, 242);
            this.btn_Nextfrm.Name = "btn_Nextfrm";
            this.btn_Nextfrm.Size = new System.Drawing.Size(206, 39);
            this.btn_Nextfrm.TabIndex = 9;
            this.btn_Nextfrm.Text = "Next Form";
            this.btn_Nextfrm.UseVisualStyleBackColor = false;
            this.btn_Nextfrm.Click += new System.EventHandler(this.btn_Nextfrm_Click);
            // 
            // btn_closefrm
            // 
            this.btn_closefrm.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btn_closefrm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btn_closefrm.Location = new System.Drawing.Point(204, 287);
            this.btn_closefrm.Name = "btn_closefrm";
            this.btn_closefrm.Size = new System.Drawing.Size(206, 39);
            this.btn_closefrm.TabIndex = 10;
            this.btn_closefrm.Text = "Close Form";
            this.btn_closefrm.UseVisualStyleBackColor = false;
            this.btn_closefrm.Click += new System.EventHandler(this.btn_closefrm_Click);
            // 
            // txtsnum
            // 
            this.txtsnum.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtsnum.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtsnum.Location = new System.Drawing.Point(457, 145);
            this.txtsnum.Name = "txtsnum";
            this.txtsnum.Size = new System.Drawing.Size(130, 20);
            this.txtsnum.TabIndex = 11;
            this.txtsnum.TextChanged += new System.EventHandler(this.txtsnum_TextChanged);
            // 
            // txtfnum
            // 
            this.txtfnum.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtfnum.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtfnum.Location = new System.Drawing.Point(151, 145);
            this.txtfnum.Name = "txtfnum";
            this.txtfnum.Size = new System.Drawing.Size(130, 20);
            this.txtfnum.TabIndex = 12;
            this.txtfnum.TextChanged += new System.EventHandler(this.txtfnum_TextChanged);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(613, 450);
            this.Controls.Add(this.txtfnum);
            this.Controls.Add(this.txtsnum);
            this.Controls.Add(this.btn_closefrm);
            this.Controls.Add(this.btn_Nextfrm);
            this.Controls.Add(this.btn_comSum);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_float);
            this.Controls.Add(this.btn_double);
            this.Controls.Add(this.btn_integer);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_integer;
        private System.Windows.Forms.Button btn_double;
        private System.Windows.Forms.Button btn_float;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_comSum;
        private System.Windows.Forms.Button btn_Nextfrm;
        private System.Windows.Forms.Button btn_closefrm;
        private System.Windows.Forms.TextBox txtsnum;
        private System.Windows.Forms.TextBox txtfnum;
    }
}