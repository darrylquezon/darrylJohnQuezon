﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuezonVinluan_WinFormLab003
{
    public partial class Form3 : Form
    {

        double doubleanswer = 25.123;

        public Form3()


        {
            InitializeComponent();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btn_comSum_Click(object sender, EventArgs e)
        {
            int fnum, snum, intanswer;
            int.TryParse(txtfnum.Text, out fnum);


            int.TryParse(txtsnum.Text, out snum);


            intanswer = fnum + snum;


            MessageBox.Show(intanswer.ToString());

            txtfnum.Clear();
            txtsnum.Clear();
        }
        private void btn_integer_Click(object sender, EventArgs e)
        {


            int intanswer = Convert.ToInt32(doubleanswer);

            MessageBox.Show(intanswer.ToString());
            
        }

        private void btn_double_Click(object sender, EventArgs e)
        {
         

            MessageBox.Show(doubleanswer.ToString());

        }

        private void btn_float_Click(object sender, EventArgs e)
        {
            float floatanswer = Convert.ToSingle(doubleanswer);

            MessageBox.Show(floatanswer.ToString("0.00"));

        }

        private void btn_closefrm_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.Show();
            this.Close();
        }

        private void btn_Nextfrm_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Hide();
        }

        private void txtfnum_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtsnum_TextChanged(object sender, EventArgs e)
        {
          
        }
    }
}
