﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuezonVinluan_WinFormLab003
{
    class declareVar
    {
            public static double total1 = 0;
            public static double total2 = 0;


            public static bool minusButtonCLicked = false;
            public static bool plusButtonCLicked = false;
            public static bool divideButtonCLicked = false;
            public static bool multiplyButtonCLicked = false;
            public static bool equalsButtonCLicked = false;

    }
}
