﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuezonVinluan_WinFormLab003
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btn_displayMess_Click(object sender, EventArgs e)

        {
           
            MessageBox.Show("Hello", "My message", MessageBoxButtons.YesNo,MessageBoxIcon.Information);

          

        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }

        private void btn_calc_Click(object sender, EventArgs e)
        {
            Calculatorform frma = new Calculatorform();
            frma.Show();
            this.Hide();

        }

        private void btn_closeform_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
