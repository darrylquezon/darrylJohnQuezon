﻿namespace QuezonVinluan_WinFormLab003
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.btn_form1 = new System.Windows.Forms.Label();
            this.btn_displayMess = new System.Windows.Forms.Button();
            this.btn_next = new System.Windows.Forms.Button();
            this.btn_calc = new System.Windows.Forms.Button();
            this.btn_closeform = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_form1
            // 
            this.btn_form1.AutoSize = true;
            this.btn_form1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_form1.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F);
            this.btn_form1.Location = new System.Drawing.Point(150, 21);
            this.btn_form1.Name = "btn_form1";
            this.btn_form1.Size = new System.Drawing.Size(360, 44);
            this.btn_form1.TabIndex = 0;
            this.btn_form1.Text = "Displaying Message";
            // 
            // btn_displayMess
            // 
            this.btn_displayMess.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_displayMess.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.btn_displayMess.Location = new System.Drawing.Point(254, 105);
            this.btn_displayMess.Name = "btn_displayMess";
            this.btn_displayMess.Size = new System.Drawing.Size(165, 57);
            this.btn_displayMess.TabIndex = 1;
            this.btn_displayMess.Text = "Display Message";
            this.btn_displayMess.UseVisualStyleBackColor = false;
            this.btn_displayMess.Click += new System.EventHandler(this.btn_displayMess_Click);
            // 
            // btn_next
            // 
            this.btn_next.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_next.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.btn_next.Location = new System.Drawing.Point(254, 168);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(165, 57);
            this.btn_next.TabIndex = 2;
            this.btn_next.Text = "Next Form";
            this.btn_next.UseVisualStyleBackColor = false;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // btn_calc
            // 
            this.btn_calc.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_calc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.btn_calc.Location = new System.Drawing.Point(254, 231);
            this.btn_calc.Name = "btn_calc";
            this.btn_calc.Size = new System.Drawing.Size(165, 57);
            this.btn_calc.TabIndex = 3;
            this.btn_calc.Text = "Calculator";
            this.btn_calc.UseVisualStyleBackColor = false;
            this.btn_calc.Click += new System.EventHandler(this.btn_calc_Click);
            // 
            // btn_closeform
            // 
            this.btn_closeform.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btn_closeform.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.btn_closeform.Location = new System.Drawing.Point(226, 309);
            this.btn_closeform.Name = "btn_closeform";
            this.btn_closeform.Size = new System.Drawing.Size(218, 45);
            this.btn_closeform.TabIndex = 4;
            this.btn_closeform.Text = "Close Form";
            this.btn_closeform.UseVisualStyleBackColor = false;
            this.btn_closeform.Click += new System.EventHandler(this.btn_closeform_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(653, 450);
            this.Controls.Add(this.btn_closeform);
            this.Controls.Add(this.btn_calc);
            this.Controls.Add(this.btn_next);
            this.Controls.Add(this.btn_displayMess);
            this.Controls.Add(this.btn_form1);
            this.Name = "Form4";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label btn_form1;
        private System.Windows.Forms.Button btn_displayMess;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.Button btn_calc;
        private System.Windows.Forms.Button btn_closeform;
    }
}

