﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuezonVinluan_WinFormLab003
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

  


        private void btnDisplay_Click(object sender, EventArgs e)
        {
            MessageBox.Show(txtname.Text);
      


        }
      
                    

            private void button1_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
