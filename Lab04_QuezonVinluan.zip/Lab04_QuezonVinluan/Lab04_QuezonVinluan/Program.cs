﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab04_QuezonVinluan
{
    class Program
    {
        static void Main(string[] args)
        {
            sample s = new sample("Darryl", "Quezon");
            Console.WriteLine(s.fname + " " + s.lname);
            Console.ReadLine();
            Console.ReadKey();
        }
    }
}
