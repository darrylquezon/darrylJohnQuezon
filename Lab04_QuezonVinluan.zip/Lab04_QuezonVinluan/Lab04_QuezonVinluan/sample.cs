﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab04_QuezonVinluan
{
    class sample
    {
       
            public string fname, lname;
            public sample(string a, string b)
            {
                fname = a;
                lname = b;
            }
    
    private sample()
        { 
            System.Console.WriteLine("Private Constructor with no Parameters");
        }

}
    
}
